import { useRef, useEffect, useCallback } from 'react';
import { useSnakeGame, Direction } from './hooks/useSnakeGame';

export default function App() {
  const {
    snake,
    food,
    gameState,
    score,
    highScore,
    difficulty,
    scoreAnimation,
    gridSize,
    startGame,
    togglePause,
    restartGame,
    changeDirection,
    changeDifficulty,
  } = useSnakeGame();

  const canvasRef = useRef<HTMLCanvasElement>(null);
  const touchStartRef = useRef<{ x: number; y: number } | null>(null);

  // Canvas rendering
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const cellSize = canvas.width / gridSize;

    // Clear canvas
    ctx.fillStyle = '#1a1a2e';
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    // Draw grid lines (subtle)
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.03)';
    ctx.lineWidth = 0.5;
    for (let i = 0; i <= gridSize; i++) {
      ctx.beginPath();
      ctx.moveTo(i * cellSize, 0);
      ctx.lineTo(i * cellSize, canvas.height);
      ctx.stroke();
      ctx.beginPath();
      ctx.moveTo(0, i * cellSize);
      ctx.lineTo(canvas.width, i * cellSize);
      ctx.stroke();
    }

    // Draw food with glow effect
    const foodX = food.x * cellSize + cellSize / 2;
    const foodY = food.y * cellSize + cellSize / 2;
    const foodRadius = cellSize * 0.4;

    // Glow
    const glowGradient = ctx.createRadialGradient(foodX, foodY, 0, foodX, foodY, cellSize);
    glowGradient.addColorStop(0, 'rgba(255, 82, 82, 0.4)');
    glowGradient.addColorStop(1, 'rgba(255, 82, 82, 0)');
    ctx.fillStyle = glowGradient;
    ctx.fillRect(food.x * cellSize - cellSize / 2, food.y * cellSize - cellSize / 2, cellSize * 2, cellSize * 2);

    // Food body
    ctx.beginPath();
    ctx.arc(foodX, foodY, foodRadius, 0, Math.PI * 2);
    const foodGradient = ctx.createRadialGradient(foodX - 2, foodY - 2, 0, foodX, foodY, foodRadius);
    foodGradient.addColorStop(0, '#ff6b6b');
    foodGradient.addColorStop(1, '#ee5a24');
    ctx.fillStyle = foodGradient;
    ctx.fill();

    // Draw snake
    snake.forEach((segment, index) => {
      const x = segment.x * cellSize;
      const y = segment.y * cellSize;
      const padding = 1;

      if (index === 0) {
        // Head with gradient
        const headGradient = ctx.createLinearGradient(x, y, x + cellSize, y + cellSize);
        headGradient.addColorStop(0, '#6c5ce7');
        headGradient.addColorStop(1, '#a29bfe');
        ctx.fillStyle = headGradient;
        ctx.beginPath();
        ctx.roundRect(x + padding, y + padding, cellSize - padding * 2, cellSize - padding * 2, 5);
        ctx.fill();

        // Eyes
        ctx.fillStyle = '#fff';
        const eyeSize = cellSize * 0.15;
        const eyeOffset = cellSize * 0.25;
        ctx.beginPath();
        ctx.arc(x + cellSize / 2 - eyeOffset, y + cellSize / 2 - eyeOffset / 2, eyeSize, 0, Math.PI * 2);
        ctx.fill();
        ctx.beginPath();
        ctx.arc(x + cellSize / 2 + eyeOffset, y + cellSize / 2 - eyeOffset / 2, eyeSize, 0, Math.PI * 2);
        ctx.fill();

        // Pupils
        ctx.fillStyle = '#2d3436';
        ctx.beginPath();
        ctx.arc(x + cellSize / 2 - eyeOffset, y + cellSize / 2 - eyeOffset / 2, eyeSize * 0.5, 0, Math.PI * 2);
        ctx.fill();
        ctx.beginPath();
        ctx.arc(x + cellSize / 2 + eyeOffset, y + cellSize / 2 - eyeOffset / 2, eyeSize * 0.5, 0, Math.PI * 2);
        ctx.fill();
      } else {
        // Body segments with gradient based on position
        const progress = index / snake.length;
        const r = Math.round(108 - progress * 40);
        const g = Math.round(92 - progress * 30);
        const b = Math.round(231 - progress * 60);
        ctx.fillStyle = `rgb(${r}, ${g}, ${b})`;
        ctx.beginPath();
        ctx.roundRect(x + padding + 1, y + padding + 1, cellSize - (padding + 1) * 2, cellSize - (padding + 1) * 2, 4);
        ctx.fill();
      }
    });

    // Overlay for paused/gameover states
    if (gameState === 'paused') {
      ctx.fillStyle = 'rgba(0, 0, 0, 0.6)';
      ctx.fillRect(0, 0, canvas.width, canvas.height);
      ctx.fillStyle = '#fff';
      ctx.font = 'bold 28px system-ui';
      ctx.textAlign = 'center';
      ctx.fillText('PAUSED', canvas.width / 2, canvas.height / 2);
      ctx.font = '16px system-ui';
      ctx.fillStyle = '#aaa';
      ctx.fillText('Press ESC or P to resume', canvas.width / 2, canvas.height / 2 + 35);
    }

    if (gameState === 'idle') {
      ctx.fillStyle = 'rgba(0, 0, 0, 0.5)';
      ctx.fillRect(0, 0, canvas.width, canvas.height);
      ctx.fillStyle = '#fff';
      ctx.font = 'bold 24px system-ui';
      ctx.textAlign = 'center';
      ctx.fillText('🐍 SNAKE', canvas.width / 2, canvas.height / 2 - 20);
      ctx.font = '14px system-ui';
      ctx.fillStyle = '#aaa';
      ctx.fillText('Press SPACE or tap to start', canvas.width / 2, canvas.height / 2 + 15);
    }

    if (gameState === 'gameover') {
      ctx.fillStyle = 'rgba(0, 0, 0, 0.7)';
      ctx.fillRect(0, 0, canvas.width, canvas.height);
      ctx.fillStyle = '#ff6b6b';
      ctx.font = 'bold 28px system-ui';
      ctx.textAlign = 'center';
      ctx.fillText('GAME OVER', canvas.width / 2, canvas.height / 2 - 20);
      ctx.font = '16px system-ui';
      ctx.fillStyle = '#fff';
      ctx.fillText(`Score: ${score}`, canvas.width / 2, canvas.height / 2 + 15);
      ctx.font = '14px system-ui';
      ctx.fillStyle = '#aaa';
      ctx.fillText('Press SPACE or tap to restart', canvas.width / 2, canvas.height / 2 + 45);
    }
  }, [snake, food, gameState, gridSize, score]);

  // Touch controls
  const handleTouchStart = useCallback((e: React.TouchEvent) => {
    const touch = e.touches[0];
    touchStartRef.current = { x: touch.clientX, y: touch.clientY };
  }, []);

  const handleTouchEnd = useCallback((e: React.TouchEvent) => {
    if (!touchStartRef.current) return;
    const touch = e.changedTouches[0];
    const dx = touch.clientX - touchStartRef.current.x;
    const dy = touch.clientY - touchStartRef.current.y;
    const minSwipe = 30;

    if (Math.abs(dx) < minSwipe && Math.abs(dy) < minSwipe) {
      // Tap - handle game state
      if (gameState === 'idle') {
        startGame();
      } else if (gameState === 'gameover') {
        restartGame();
      }
      return;
    }

    if (gameState !== 'playing') return;

    if (Math.abs(dx) > Math.abs(dy)) {
      changeDirection(dx > 0 ? 'RIGHT' : 'LEFT');
    } else {
      changeDirection(dy > 0 ? 'DOWN' : 'UP');
    }
    touchStartRef.current = null;
  }, [gameState, startGame, restartGame, changeDirection]);

  // Responsive canvas sizing
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const resizeCanvas = () => {
      const container = canvas.parentElement;
      if (!container) return;
      const size = Math.min(container.clientWidth, 500);
      canvas.width = size;
      canvas.height = size;
    };

    resizeCanvas();
    window.addEventListener('resize', resizeCanvas);
    return () => window.removeEventListener('resize', resizeCanvas);
  }, []);

  const handleDirectionButton = (dir: Direction) => {
    if (gameState === 'playing') {
      changeDirection(dir);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-slate-900 to-gray-900 flex flex-col items-center justify-center p-4 select-none">
      {/* Header */}
      <div className="w-full max-w-lg mb-4">
        <h1 className="text-3xl font-bold text-center text-white mb-1">
          🐍 Snake
        </h1>
        <p className="text-center text-gray-400 text-sm">Use arrow keys, WASD, or swipe to play</p>
      </div>

      {/* Score Board */}
      <div className="w-full max-w-lg flex justify-between items-center mb-3 px-2">
        <div className="flex flex-col items-center">
          <span className="text-xs text-gray-400 uppercase tracking-wider">Score</span>
          <span className={`text-2xl font-bold text-white transition-transform ${scoreAnimation ? 'scale-125 text-green-400' : ''}`}>
            {score}
          </span>
        </div>
        <div className="flex gap-2">
          {(['easy', 'medium', 'hard'] as const).map((diff) => (
            <button
              key={diff}
              onClick={() => changeDifficulty(diff)}
              disabled={gameState === 'playing' || gameState === 'paused'}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold uppercase tracking-wide transition-all
                ${difficulty === diff
                  ? 'bg-purple-600 text-white shadow-lg shadow-purple-600/30'
                  : 'bg-gray-800 text-gray-400 hover:bg-gray-700 hover:text-white'
                }
                ${(gameState === 'playing' || gameState === 'paused') ? 'opacity-50 cursor-not-allowed' : 'cursor-pointer'}
              `}
            >
              {diff}
            </button>
          ))}
        </div>
        <div className="flex flex-col items-center">
          <span className="text-xs text-gray-400 uppercase tracking-wider">Best</span>
          <span className="text-2xl font-bold text-yellow-400">
            {highScore}
          </span>
        </div>
      </div>

      {/* Game Board */}
      <div className="w-full max-w-lg aspect-square relative rounded-2xl overflow-hidden border-2 border-gray-700/50 shadow-2xl shadow-purple-900/20">
        <canvas
          ref={canvasRef}
          className="w-full h-full"
          onTouchStart={handleTouchStart}
          onTouchEnd={handleTouchEnd}
        />
      </div>

      {/* Controls */}
      <div className="w-full max-w-lg mt-4 flex flex-col items-center gap-3">
        {/* Action Buttons */}
        <div className="flex gap-3">
          {gameState === 'idle' && (
            <button
              onClick={startGame}
              className="px-6 py-2.5 bg-green-600 hover:bg-green-500 text-white font-semibold rounded-xl shadow-lg shadow-green-600/30 transition-all hover:scale-105 active:scale-95"
            >
              ▶ Start Game
            </button>
          )}
          {(gameState === 'playing' || gameState === 'paused') && (
            <button
              onClick={togglePause}
              className="px-5 py-2.5 bg-yellow-600 hover:bg-yellow-500 text-white font-semibold rounded-xl shadow-lg shadow-yellow-600/30 transition-all hover:scale-105 active:scale-95"
            >
              {gameState === 'paused' ? '▶ Resume' : '⏸ Pause'}
            </button>
          )}
          {(gameState === 'playing' || gameState === 'paused') && (
            <button
              onClick={restartGame}
              className="px-5 py-2.5 bg-red-600 hover:bg-red-500 text-white font-semibold rounded-xl shadow-lg shadow-red-600/30 transition-all hover:scale-105 active:scale-95"
            >
              ↻ Restart
            </button>
          )}
          {gameState === 'gameover' && (
            <button
              onClick={restartGame}
              className="px-6 py-2.5 bg-green-600 hover:bg-green-500 text-white font-semibold rounded-xl shadow-lg shadow-green-600/30 transition-all hover:scale-105 active:scale-95"
            >
              ↻ Play Again
            </button>
          )}
        </div>

        {/* D-Pad for mobile */}
        <div className="grid grid-cols-3 gap-1 mt-2 md:hidden">
          <div></div>
          <button
            onTouchStart={(e) => { e.preventDefault(); handleDirectionButton('UP'); }}
            className="w-14 h-14 bg-gray-800 hover:bg-gray-700 active:bg-purple-700 rounded-xl flex items-center justify-center text-white text-xl transition-colors"
          >
            ▲
          </button>
          <div></div>
          <button
            onTouchStart={(e) => { e.preventDefault(); handleDirectionButton('LEFT'); }}
            className="w-14 h-14 bg-gray-800 hover:bg-gray-700 active:bg-purple-700 rounded-xl flex items-center justify-center text-white text-xl transition-colors"
          >
            ◀
          </button>
          <div className="w-14 h-14 bg-gray-800/50 rounded-xl flex items-center justify-center text-gray-600 text-xs">
            ●
          </div>
          <button
            onTouchStart={(e) => { e.preventDefault(); handleDirectionButton('RIGHT'); }}
            className="w-14 h-14 bg-gray-800 hover:bg-gray-700 active:bg-purple-700 rounded-xl flex items-center justify-center text-white text-xl transition-colors"
          >
            ▶
          </button>
          <div></div>
          <button
            onTouchStart={(e) => { e.preventDefault(); handleDirectionButton('DOWN'); }}
            className="w-14 h-14 bg-gray-800 hover:bg-gray-700 active:bg-purple-700 rounded-xl flex items-center justify-center text-white text-xl transition-colors"
          >
            ▼
          </button>
          <div></div>
        </div>
      </div>

      {/* Footer info */}
      <div className="mt-6 text-center text-gray-500 text-xs">
        <p>Speed: {difficulty === 'easy' ? 'Slow' : difficulty === 'medium' ? 'Medium' : 'Fast'} • Grid: {gridSize}×{gridSize}</p>
      </div>
    </div>
  );
}
